# Ecommerce API — Express + MySQL

API RESTful para gestionar productos con imagen automática desde API externa (Lorem Picsum). Incluye:

- CRUD `/api/products` (GET/GET:id/POST/PUT/DELETE)
- MySQL (tabla `products`)
- Validación con Joi
- Logging con morgan
- Manejo centralizado de errores
- Despliegue en Render/Railway
- Ejemplos `curl`

## Requisitos
- Node 18+
- MySQL 8+ (local o gestionado — p.ej., Railway)

## Instalación
```bash
cp .env.example .env
# edita tus credenciales de DB
npm install
npm run dev
```

## SQL de base de datos
```sql
CREATE DATABASE IF NOT EXISTS ecommerce_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecommerce_db;

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL,
  image_url VARCHAR(500) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Endpoints
- `GET    /api/products`
- `GET    /api/products/:id`
- `POST   /api/products` (imagen automática desde API externa)
- `PUT    /api/products/:id`
- `DELETE /api/products/:id`

### Ejemplos curl
```bash
# Crear
curl -X POST http://localhost:3000/api/products   -H "Content-Type: application/json"   -d '{
    "name": "Camiseta GenZ",
    "description": "Algodón orgánico",
    "price": 49.90,
    "stock": 25
  }'

# Listar
curl http://localhost:3000/api/products

# Obtener por ID
curl http://localhost:3000/api/products/1

# Actualizar
curl -X PUT http://localhost:3000/api/products/1   -H "Content-Type: application/json"   -d '{ "price": 39.99, "stock": 50 }'

# Eliminar
curl -X DELETE http://localhost:3000/api/products/1
```

## Deploy (Render/Railway)
1. Sube el repo a GitHub.
2. Crea un servicio en Render/Railway y configura variables de entorno: `PORT`, `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, `CORS_ORIGINS`.
3. Build: `npm install` — Start: `npm start`.
4. Prueba `/health` y los endpoints.

## Notas
- API externa: `https://picsum.photos/v2/list` con fallback a URL seed (si hay timeouts).
- Cambia CORS con `CORS_ORIGINS` si necesitas habilitar otros orígenes.
```
