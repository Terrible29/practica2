const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const productsRouter = require('./routes/products');
const notFound = require('./middlewares/notFound');
const errorHandler = require('./middlewares/errorHandler');

const app = express();

// Middlewares base
app.use(express.json());
app.use(morgan('dev'));

// CORS configurable
const origins = process.env.CORS_ORIGINS?.split(',') || ['*'];
app.use(cors({ origin: origins }));

// Rutas
app.get('/health', (_, res) => res.json({ status: 'ok' }));
app.use('/api/products', productsRouter);

// 404 + Errores
app.use(notFound);
app.use(errorHandler);

module.exports = app;
