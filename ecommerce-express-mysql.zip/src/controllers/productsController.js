const axios = require('axios');
const pool = require('../db');
const { createProductSchema, updateProductSchema } = require('../validators/productSchema');

async function fetchRandomImageUrl() {
  try {
    const page = Math.floor(Math.random() * 100) + 1;
    const { data } = await axios.get(`https://picsum.photos/v2/list?page=${page}&limit=1`, { timeout: 5000 });
    if (Array.isArray(data) && data.length > 0) {
      return data[0].download_url;
    }
  } catch (e) {
    // ignore network errors, we'll use fallback below
  }
  const seed = Math.random().toString(36).slice(2);
  return `https://picsum.photos/seed/${seed}/600/400`;
}

exports.list = async (req, res, next) => {
  try {
    const [rows] = await pool.query('SELECT * FROM products ORDER BY id DESC');
    res.json(rows);
  } catch (err) { next(err); }
};

exports.getById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Product not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.create = async (req, res, next) => {
  try {
    const { error, value } = createProductSchema.validate(req.body, { abortEarly: false });
    if (error) {
      error.status = 400;
      error.details = error.details.map(d => d.message);
      throw error;
    }

    const imageUrl = await fetchRandomImageUrl();
    const { name, description, price, stock } = value;

    const [result] = await pool.query(
      'INSERT INTO products (name, description, price, stock, image_url) VALUES (?, ?, ?, ?, ?)',
      [name, description, price, stock, imageUrl]
    );
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

exports.update = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [exist] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
    if (exist.length === 0) return res.status(404).json({ error: 'Product not found' });

    const { error, value } = updateProductSchema.validate(req.body, { abortEarly: false });
    if (error) {
      error.status = 400;
      error.details = error.details.map(d => d.message);
      throw error;
    }

    const fields = [];
    const params = [];
    for (const [k, v] of Object.entries(value)) {
      fields.push(`${k} = ?`);
      params.push(v);
    }
    if (fields.length === 0) return res.status(400).json({ error: 'No fields to update' });

    params.push(id);
    await pool.query(`UPDATE products SET ${fields.join(', ')} WHERE id = ?`, params);
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.remove = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [result] = await pool.query('DELETE FROM products WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Product not found' });
    res.status(204).send();
  } catch (err) { next(err); }
};
